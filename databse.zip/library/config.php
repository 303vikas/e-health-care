<?php
ini_set('display_errors', 'Off');
//ob_start("ob_gzhandler");
//error_reporting(E_ALL);

// start the session
session_start();
// database connection config
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'project';

$connect=mysqli_connect('localhost','root','','project') or die('database error'); 

// get the shop configuration ( name, addres, etc ), all page need it
//$shopConfig = getShopConfig();
?>